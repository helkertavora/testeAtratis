<?php
require_once 'core/topo.php';
?>  

	<div id="box404" style="background:url(<?php print $path; ?>/img/funcap3.jpg) no-repeat; height:500px; left:50%; margin:-250px 0 0 -250px;	position:absolute; top:300px; width:500px;">
     	<div>
        	<div style="height:480px;"></div>
        	<p style="text-align:center">	
				<button class="btn btn-primary" type="button" onClick="javascript:location='<?php print $path; ?>/'">Home</button>
			</p>
    	</div>
    </div>
</div> <!-- /container -->

<script src="<?php print $path; ?>/js/jquery.js"></script>
<script src="<?php print $path; ?>/js/bootstrap.js"></script>
</body>
</html>	