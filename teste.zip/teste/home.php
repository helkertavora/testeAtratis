<?php
require_once 'core/topo.php';
?>  
      <div class="starter-template">
        <!--<p class="lead">&nbsp;</p>
        <p class="lead">&nbsp;</p>
        <p class="lead">&nbsp;</p>
        <p class="lead">&nbsp;</p>
        <p class="lead">&nbsp;</p>
        <p class="lead">&nbsp;</p>-->
        <p class="lead"><img src="./img/atratis.jpg" style="width:800px"></p>
      </div>
<?php
require_once 'core/fim.php';
?> 