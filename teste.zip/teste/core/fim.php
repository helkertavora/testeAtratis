﻿    <hr>
  	<footer>
    	<p>&copy; <a href="#" target="_blank">Teste Atratis Digital <?php print date('Y');?></a></p>
  	</footer>
    
    </div><!-- /.container -->
    <!--<script src="<?php print $path; ?>/js/jquery-1.10.2.min.js"></script>-->


<script src="<?php print $path; ?>/js/jquery.js"></script>
<script src="<?php print $path; ?>/js/bootstrap.min.js"></script>
<script src="<?php print $path; ?>/js/bootstrap-editable.js"></script>
<script src="<?php print $path; ?>/js/jquery.validate.js"></script>
<script src="<?php print $path; ?>/js/memberUpdate.js"></script>

<!--<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">-->

<!--<script src="<?php print $path; ?>/js/jquery-ui-1.10.3.min.js"></script>-->
<script src="<?php print $path; ?>/js/jquery.maskedinput.min.js"></script>
<script src="<?php print $path; ?>/js/chosen.jquery.min.js"></script>
<!--<script src="<?php print $path; ?>/js/jquery.mousewheel.js"></script>-->



