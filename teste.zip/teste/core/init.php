<?php 

//require_once 'connect/database.php';
require_once 'connect/conectar.php';
require_once 'classes/general.php';


$general = new General();
$errors = array();

date_default_timezone_set('America/Fortaleza');

$path = ".";	


?>